/**
 * Box implementation.
 * This package consists of a general box class, a manager for all box instances,
 * a small util class. If a box is resizable and/or draggable an instance of these
 * property classes are instantiated.
 */